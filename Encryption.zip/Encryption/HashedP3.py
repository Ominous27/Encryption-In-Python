import bcrypt

passwd = b'Manvendra Sang'
salt = bcrypt.gensalt()
hashed = bcrypt.hashpw(passwd, salt)

print(salt)
print(hashed)