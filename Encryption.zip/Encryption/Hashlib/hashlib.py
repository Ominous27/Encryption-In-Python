import hashlib 

str2hash = "Manvendra Sang"
 
result = hashlib.sha224(str2hash.encode()) 

print("The hexadecimal equivalent of hash is : ", end ="") 
print(result.hexdigest()) 